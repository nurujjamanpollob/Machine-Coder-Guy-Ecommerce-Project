package com.nurujjamanpollob.machinecoderguystore.commonlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonLibraryApplicationTests {

    @Test
    void contextLoads() {
    }

}
